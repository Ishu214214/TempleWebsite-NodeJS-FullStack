const express =require("express");
const path = require("path");
const fs = require("fs");
const port =80;

const bodyParser = require('body-parser').json();

//file sa daata  uutha na ma help karta ha
const app=express();

app.use('/static',express.static('static'));

//form ka data ko express tuck laaay ga
 app.use(express.urlencoded({ extended: true }));

//set template engion as pug 
app.set('view engine','pug');

//set view directory
app.set('views',path.join(__dirname,'views'));

const con ="this is ";
const params={'ishu':"kumar",'content':con};


app.get("/", (req, res) =>{
    res.status(200).render('index.pug',params);
});

app.get("/about", (req, res) =>{
    res.status(200).render('about.pug',params);
});

app.get("/contact", (req, res) =>{
    res.status(200).render('contact.pug',params);
});

app.get("/services", (req, res) =>{
    res.status(200).render('service.pug',params);
});


app.post("/contact" , bodyParser,(req, res) =>{
    console.log(req.body);
    Email=req.body.Email;
    Password=req.body.Password;
    Gender=req.body.Gender;
    Address=req.body.Address;
    City=req.body.City;
    Zip=req.body.Zip;

    let outputToWrite=`email is ${Email} and ${Password} and ${Gender} and ${Address} and ${City} ${Zip}`;
    fs.writeFileSync('output.txt',outputToWrite);
   
   const params={'message':"kumar oo9o8 9o8790o"};
    res.status(200).render('contact.pug',params);
});

app.listen(port,()=>{
    console.log(`Server running at http://localhost:${port}/`);
})

